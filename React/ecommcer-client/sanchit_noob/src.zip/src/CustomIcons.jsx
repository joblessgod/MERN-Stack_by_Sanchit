import React from 'react'
import { CiMail } from "react-icons/ci";

export default function CustomIcons() {
  return (
    <>
    <CiMail/>
    </>
  )
}
