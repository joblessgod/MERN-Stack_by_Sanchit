import React from 'react'


export default function Home() {
    return (
        <>
            <h1 className='bg-slate-300	'> Homies are here!</h1>


        </>
    )
}
