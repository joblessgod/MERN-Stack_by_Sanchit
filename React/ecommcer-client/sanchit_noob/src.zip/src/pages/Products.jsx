import React from 'react'

export default function Products() {
  return (
    <>
      <h1 className='bg-slate-300	'> Products</h1>

    </>
  )
}
