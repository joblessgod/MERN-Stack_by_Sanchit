import React from 'react'

export default function () {
  return (
    <>
            <h1 className='bg-slate-300	'> Login</h1>
    
    </>
  )
}
