import React from 'react'

export default function Blogs() {
  return (
    <>
      <h1 className='bg-slate-300	'> Blogsss</h1>

    </>
  )
}
