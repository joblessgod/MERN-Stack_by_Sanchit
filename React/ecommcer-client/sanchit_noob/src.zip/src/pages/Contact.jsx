import React from 'react'

export default function Contact() {
  return (
    <>
      <h1 className='bg-slate-300	'> Contact</h1>

    </>
  )
}
