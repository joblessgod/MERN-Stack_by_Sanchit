const SELLER = "seller"
const BUYER = "buyer"

module.exports = {
    SELLER, BUYER
}